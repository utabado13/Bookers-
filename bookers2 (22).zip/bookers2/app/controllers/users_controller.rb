class UsersController < ApplicationController
  def index
    @book = Book.new
    @users = User.all
    @user = User.find current_user.id
    @books = Book.all
  end

  def show
    @book = Book.new
    
    @user = User.find(params[:id])
    @books = @user.books
  end

  def edit
    @user = User.find(params[:id])
    if @user.id == current_user.id
    #ここで編集画面を表示する。
    render :edit
  else 
    #redirect_to ログインユーザーのshowページ
    redirect_to user_path(current_user)
  end 
    
  end

  def new
    @book = Book.new
  end

  def update
    @user = User.find(params[:id])
    if @user.update(user_params)
      redirect_to @user, notice: 'user was successfully updated.'
    else
      render :edit
    end
  end

  def create
    @book = Book.new
    if @book.save
      redirect_to @book, notice: 'Book was successfully created.'
    else
      render :new
    end
  end

  private
  def set_book
      @user = User.find(params[:id])
  end
  def user_params
    params.require(:user).permit(:name, :introduction, :profile_image)
  end

end
