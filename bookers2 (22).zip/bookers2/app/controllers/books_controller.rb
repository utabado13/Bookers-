class BooksController < ApplicationController
  before_action :set_book, only: [:show, :edit, :update, :destroy]

  def index
    @books = Book.all
    @user = User.find current_user.id
    @book = Book.new
  end

  def show
    
    @book = Book.find(params[:id])  # 表示用
    @book_new = Book.new  # 投稿用（ビューの form_withではこの @book_new変数を指定する。または部分テンプレートにこの @book_new変数を渡す）
    @user = @book.user
  
     
     #@book = Book.find(params[:id])
  end

  # def new
  #   @book = Book.new
  # end

  def edit
    @book = Book.find(params[:id])
     
    if @book.user.id == current_user.id
    #ここで編集画面を表示する。
    render :edit
    else 
    #redirect_to ログインユーザーのshowページ
    redirect_to books_path
    end
 end 
 
  def create
    @book = Book.new(book_params)

    @book.user = current_user


    if @book.save
      redirect_to @book, notice: 'You have created book successfully.'
    else
      @books = Book.all
      @user = current_user
      render :index
    end
  end

  def update
    if @book.update(book_params)
      redirect_to @book, notice: 'You have updated book successfully.'
    else
      render :edit
    end
  end

  def destroy
    @book.destroy
    redirect_to books_url, notice: 'Book was successfully destroyed.'
  end

  private
    def set_book
      @book = Book.find(params[:id])
    end

    def book_params
      params.require(:book).permit(:title, :body)
    end
end

