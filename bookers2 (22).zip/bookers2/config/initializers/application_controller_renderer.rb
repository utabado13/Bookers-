# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = 'cfecbc4e56d62132ceb5818abb35cc8138e2d5d3528ccc6a3c105d061af06ad402cb3dbc302cb390dd3c1cc9823981e4ee38bc2bdf6c1893825724510917c966'

